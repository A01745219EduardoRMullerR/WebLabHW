//Importamos el metodo createContext de react 
import { createContext } from 'react'; 
   
//Creamos y exportamos una variable que inicializamos con la ejecución del metodo createContext. El parámetro 
// que recibe es el valor por default. 
export const UserContext = createContext(null); 