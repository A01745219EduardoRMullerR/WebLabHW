import React from 'react';

export const Hooks = () => {

    return (
        <>
            <h1>React Hooks</h1>
        </>
    )
    
}